import UIKit



func metodo1(lista:[Int]) -> Bool{
    var listaPares : [Int] = []
    var listaImpares : [Int] = []
    for index in 0...lista.count {
        if lista[index] % 2 == 0 {
            listaPares.append(index)
        }else{
            listaImpares.append(index)
        }
    }

    let totalPres = listaPares.reduce(0, +)
    let totalImpares = listaImpares.reduce(0, +)

    if totalPres > totalImpares {
        return true
    }else{
        return false
    }
}

var lista = [2,5,10,20,4]
metodo1(lista: lista)


func metodo2(num:Int){
}
